plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace="ai.eliteauraxp.app"; compileSdk=35
 defaultConfig { applicationId="ai.eliteauraxp.app"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" }
}
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.webkit:webkit:1.12.1") }
