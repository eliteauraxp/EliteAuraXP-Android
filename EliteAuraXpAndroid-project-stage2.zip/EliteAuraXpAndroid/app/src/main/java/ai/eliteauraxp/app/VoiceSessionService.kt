package ai.eliteauraxp.app

import android.app.*
import android.content.*
import android.media.*
import android.os.*
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.sqrt

/** Explicitly-started microphone FGS. Captures short VAD-delimited utterances and
 * posts WAV to Supabase /functions/v1/stt with the signed-in user's JWT. */
class VoiceSessionService : Service() {
    @Volatile private var recorder: AudioRecord? = null
    private val alive = AtomicBoolean(false)
    @Volatile private var paused = false
    @Volatile private var worker: Thread? = null

    companion object {
        @Volatile var currentState = "idle"
            private set
        @Volatile private var accessToken: String = ""
        @Volatile private var refreshToken: String = ""
        @Volatile private var ttsEngine: android.speech.tts.TextToSpeech? = null
        @Volatile private var ttsReady = false
        private const val CHANNEL = "voice_session"
        private const val NOTIFICATION_ID = 6701
        private const val ACTION_STATE = "ai.eliteauraxp.VOICE_STATE"
        private const val ACTION_TRANSCRIPT = "ai.eliteauraxp.VOICE_TRANSCRIPT"
        private const val ACTION_SESSION = "ai.eliteauraxp.VOICE_SESSION_REFRESHED"
        private const val SAMPLE_RATE = 16_000
        private const val VAD_RMS_THRESHOLD = 520.0
        private const val END_SILENCE_MS = 850L
        private const val MAX_UTTERANCE_MS = 25_000L

        fun updateSessionTokens(access: String, refresh: String) { accessToken = access; refreshToken = refresh }
        @Synchronized fun speak(c: Context, text: String) {
            // Compatibility bridge only; Stage 2 does not route AI replies to background TTS.
            if (ttsEngine == null) {
                ttsEngine = android.speech.tts.TextToSpeech(c.applicationContext) { status ->
                    ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS
                    if (ttsReady) ttsEngine?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "eliteauraxp-tts")
                }
            } else if (ttsReady) ttsEngine?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "eliteauraxp-tts")
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Voice session", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "START" -> startSession()
            "PAUSE" -> if (alive.get()) { paused = true; state("paused") }
            "RESUME" -> if (alive.get()) { paused = false; state("listening") }
            "STOP" -> stopSession("stopped")
        }
        return START_NOT_STICKY
    }

    private fun startSession() {
        if (alive.get()) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            state("error", "Microphone permission is required."); stopSelf(); return
        }
        if (accessToken.isBlank()) {
            state("error", "Sign in to your Supabase account before starting native STT."); stopSelf(); return
        }
        startForeground(NOTIFICATION_ID, notification("starting"))
        alive.set(true); paused = false
        state("starting")
        worker = thread(name = "eliteauraxp-native-stt") { captureLoop() }
    }

    /** Reopens AudioRecord after Resume; Pause releases the microphone instead of silently capturing. */
    private fun captureLoop() {
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { fail("This device does not support 16 kHz microphone capture."); return }
        val bufferSize = maxOf(min, 4096)
        try {
            while (alive.get()) {
                while (alive.get() && paused) Thread.sleep(100)
                if (!alive.get()) break
                val audio = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
                if (audio.state != AudioRecord.STATE_INITIALIZED) { audio.release(); fail("Could not initialize microphone."); return }
                recorder = audio
                var finishedSegment: ByteArray? = null
                try {
                    audio.startRecording()
                    if (audio.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("Microphone did not start recording.")
                    state("listening")
                    val bytes = ByteArray(2048)
                    val preRoll = ArrayDeque<ByteArray>()
                    var segment: ByteArrayOutputStream? = null
                    var speechStart = 0L
                    var lastVoice = 0L
                    var aboveFrames = 0
                    while (alive.get() && !paused) {
                        val n = audio.read(bytes, 0, bytes.size, AudioRecord.READ_BLOCKING)
                        if (!alive.get() || paused) break
                        if (n < 0) throw IllegalStateException("AudioRecord.read failed ($n).")
                        if (n == 0) continue
                        val frame = bytes.copyOf(n)
                        val now = SystemClock.elapsedRealtime()
                        val rms = rms16(frame)
                        if (segment == null) {
                            preRoll.addLast(frame)
                            while (preRoll.size > 4) preRoll.removeFirst()
                            aboveFrames = if (rms >= VAD_RMS_THRESHOLD) aboveFrames + 1 else 0
                            if (aboveFrames >= 2) {
                                val utteranceBuffer = ByteArrayOutputStream()
                                segment = utteranceBuffer
                                preRoll.forEach { frameBytes -> utteranceBuffer.write(frameBytes) }
                                preRoll.clear(); speechStart = now; lastVoice = now
                            }
                        } else {
                            val activeSegment = segment ?: continue
                            activeSegment.write(frame)
                            if (rms >= VAD_RMS_THRESHOLD) lastVoice = now
                            if (now - lastVoice >= END_SILENCE_MS || now - speechStart >= MAX_UTTERANCE_MS) {
                                val utterance = activeSegment.toByteArray()
                                segment = null; preRoll.clear(); aboveFrames = 0
                                if (utterance.size >= SAMPLE_RATE * 2 / 3) finishedSegment = utterance
                                break
                            }
                        }
                    }
                } finally {
                    if (recorder === audio) recorder = null
                    try { if (audio.recordingState == AudioRecord.RECORDSTATE_RECORDING) audio.stop() } catch (_: Exception) { }
                    try { audio.release() } catch (_: Exception) { }
                }
                if (alive.get() && !paused) finishedSegment?.let { transcribe(it) }
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (e: Exception) {
            if (alive.get()) fail(e.message ?: "Microphone capture failed.")
        } finally {
            releaseRecorder()
        }
    }

    private fun transcribe(pcm: ByteArray) {
        var token = accessToken
        if (token.isBlank()) { emitError("Supabase session expired. Reopen the app and sign in."); return }
        state("processing_stt")
        try {
            val wav = SupabaseSttClient.wavFromPcm16(pcm, SAMPLE_RATE)
            val result = try { SupabaseSttClient.transcribe(wav, token) }
            catch (e: SupabaseSttClient.SttException) {
                if (e.httpStatus != 401) throw e
                val fresh = SupabaseSttClient.refreshSession(refreshToken)
                updateSessionTokens(fresh.access, fresh.refresh); token = fresh.access
                sendBroadcast(Intent(ACTION_SESSION).setPackage(packageName).putExtra("access", fresh.access).putExtra("refresh", fresh.refresh))
                SupabaseSttClient.transcribe(wav, token)
            }
            if (!alive.get()) return
            sendBroadcast(Intent(ACTION_TRANSCRIPT).setPackage(packageName).putExtra("transcript", result.transcript))
        } catch (e: SupabaseSttClient.SttException) {
            emitError(e.message ?: "Transcription failed.")
            if (e.httpStatus == 401 || e.httpStatus == 403) stopSession("error", "Supabase authorization failed; sign in again.")
        } catch (e: Exception) {
            if (alive.get()) emitError(e.message ?: "Could not reach Supabase STT.")
        } finally {
            if (alive.get() && !paused) state("listening")
        }
    }

    private fun rms16(data: ByteArray): Double {
        val count = data.size / 2
        if (count == 0) return 0.0
        var sum = 0.0; var i = 0
        while (i + 1 < data.size) {
            val sample = ((data[i + 1].toInt() shl 8) or (data[i].toInt() and 0xff)).toShort().toDouble()
            sum += sample * sample; i += 2
        }
        return sqrt(sum / count)
    }

    private fun fail(message: String) { emitError(message); stopSession("error", message) }
    private fun emitError(message: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra("state", currentState).putExtra("error", message))
    }

    private fun state(value: String, error: String? = null) {
        currentState = value
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(error ?: value))
        val b = Intent(ACTION_STATE).setPackage(packageName).putExtra("state", value)
        if (error != null) b.putExtra("error", error)
        sendBroadcast(b)
    }

    private fun notification(status: String): Notification = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("EliteAuraXp · Avni STT")
        .setContentText(status.replace('_', ' '))
        .setOngoing(alive.get()).setCategory(NotificationCompat.CATEGORY_SERVICE)
        .addAction(android.R.drawable.ic_media_pause, "Pause", action("PAUSE"))
        .addAction(android.R.drawable.ic_media_play, "Resume", action("RESUME"))
        .addAction(android.R.drawable.ic_media_stop, "Stop", action("STOP"))
        .build()

    private fun action(name: String): PendingIntent = PendingIntent.getService(this, name.hashCode(),
        Intent(this, VoiceSessionService::class.java).setAction(name),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun releaseRecorder() {
        val old = recorder; recorder = null
        try { if (old?.recordingState == AudioRecord.RECORDSTATE_RECORDING) old.stop() } catch (_: Exception) { }
        try { old?.release() } catch (_: Exception) { }
    }

    private fun stopSession(finalState: String = "stopped", message: String? = null) {
        if (!alive.getAndSet(false) && finalState == "stopped") { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        paused = false
        try { recorder?.stop() } catch (_: Exception) { }
        worker?.interrupt(); worker = null
        SupabaseSttClient.cancelCurrent()
        releaseRecorder()
        if (message != null) state(finalState, message) else state(finalState)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) { super.onTaskRemoved(rootIntent) }
    override fun onDestroy() { if (alive.get()) stopSession("stopped"); releaseRecorder(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
