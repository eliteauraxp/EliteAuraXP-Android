package ai.eliteauraxp.app
import android.content.*
class VoiceActionReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){c.startService(Intent(c,VoiceSessionService::class.java).setAction(i.action))}}
