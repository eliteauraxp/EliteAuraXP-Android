package ai.eliteauraxp.app

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Authenticated multipart client for the existing Supabase Edge Function.
 * No Groq credential is shipped here; the Edge Function owns GROQ_API_KEY. */
internal object SupabaseSttClient {
    private const val PROJECT_URL = "https://sfbyltxmezgebfrdvzgi.supabase.co"
    private const val PUBLISHABLE_KEY = "sb_publishable_euG-QCULvyGyB42D0C4f1g_VWV5-l-n"
    private const val MODEL = "whisper-large-v3-turbo"

    data class Result(val transcript: String, val requestId: String)
    data class Tokens(val access: String, val refresh: String)
    @Volatile private var activeConnection: HttpURLConnection? = null
    fun cancelCurrent() { activeConnection?.disconnect() }

    fun refreshSession(refreshToken: String): Tokens {
        require(refreshToken.isNotBlank()) { "Supabase refresh token is unavailable; reopen the app and sign in." }
        val conn = (URL("$PROJECT_URL/auth/v1/token?grant_type=refresh_token").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15_000; readTimeout = 20_000; doOutput = true
            setRequestProperty("apikey", PUBLISHABLE_KEY); setRequestProperty("Content-Type", "application/json")
        }
        try {
            conn.outputStream.use { it.write(JSONObject().put("refresh_token", refreshToken).toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode; val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw SttException(code, "Supabase session refresh failed (HTTP $code). Sign in again.")
            val json = JSONObject(body); val access = json.optString("access_token"); val refresh = json.optString("refresh_token", refreshToken)
            if (access.isBlank()) throw SttException(code, "Supabase did not return a refreshed session.")
            return Tokens(access, refresh)
        } finally { conn.disconnect() }
    }

    fun transcribe(wav: ByteArray, accessToken: String, language: String? = null, prompt: String? = null): Result {
        require(wav.size > 44) { "Recorded audio is empty." }
        require(accessToken.isNotBlank()) { "Sign in to Supabase before using voice transcription." }
        val boundary = "----EliteAuraXp-${UUID.randomUUID()}"
        val conn = (URL("$PROJECT_URL/functions/v1/stt").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $accessToken")
            setRequestProperty("apikey", PUBLISHABLE_KEY)
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Client-Info", "eliteauraxp-android")
        }
        activeConnection = conn
        try {
            conn.outputStream.buffered().use { out ->
                fun field(name: String, value: String) {
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray(Charsets.UTF_8))
                }
                field("model", MODEL)
                field("response_format", "json")
                field("temperature", "0")
                language?.takeIf { it.isNotBlank() }?.let { field("language", it) }
                prompt?.takeIf { it.isNotBlank() }?.let { field("prompt", it.take(500)) }
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray(Charsets.UTF_8))
                out.write(wav)
                out.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(body).optString("error").ifBlank { JSONObject(body).optString("message") } }.getOrNull().orEmpty()
                val msg = when (code) {
                    401, 403 -> "Supabase session expired or not authorized. Sign in again."
                    413 -> "Audio segment is too large. Please speak in shorter turns."
                    429 -> "Transcription is busy or rate-limited. Wait a moment and try again."
                    else -> detail.ifBlank { "STT Edge Function returned HTTP $code." }
                }
                throw SttException(code, msg)
            }
            val json = JSONObject(body)
            val transcript = json.optString("text", json.optString("transcript")).trim()
            if (transcript.isBlank()) throw SttException(code, "STT returned no transcript. Check the Edge Function response schema.")
            return Result(transcript, json.optString("request_id"))
        } finally {
            activeConnection = null
            conn.disconnect()
        }
    }

    fun wavFromPcm16(pcm: ByteArray, sampleRate: Int = 16_000): ByteArray {
        val out = ByteArrayOutputStream(44 + pcm.size)
        fun ascii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
        fun u16(n: Int) { out.write(n and 0xff); out.write((n shr 8) and 0xff) }
        fun u32(n: Int) { out.write(n and 0xff); out.write((n shr 8) and 0xff); out.write((n shr 16) and 0xff); out.write((n shr 24) and 0xff) }
        ascii("RIFF"); u32(36 + pcm.size); ascii("WAVE"); ascii("fmt "); u32(16); u16(1); u16(1)
        u32(sampleRate); u32(sampleRate * 2); u16(2); u16(16); ascii("data"); u32(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    class SttException(val httpStatus: Int, message: String) : Exception(message)
}
