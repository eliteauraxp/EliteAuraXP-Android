package ai.eliteauraxp.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.net.Uri
import android.webkit.*
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject

class MainActivity: ComponentActivity() {
 lateinit var web: WebView
 private var pendingOAuth:Uri?=null
 private var pendingWebMic:PermissionRequest?=null
 private var serviceReceiverRegistered=false
 private val serviceReceiver=object:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){when(intent.action){"ai.eliteauraxp.VOICE_STATE"->{val d=JSONObject().put("state",intent.getStringExtra("state")?:"idle");intent.getStringExtra("error")?.let{dispatchWeb("nativeVoiceError",JSONObject().put("message",it))};dispatchWeb("nativeVoiceStateChanged",d)};"ai.eliteauraxp.VOICE_TRANSCRIPT"->{val d=JSONObject().put("text",intent.getStringExtra("transcript")?:"");dispatchWeb("nativeVoiceTranscript",d)};"ai.eliteauraxp.VOICE_SESSION_REFRESHED"->{dispatchWeb("nativeSessionRefreshed",JSONObject().put("access",intent.getStringExtra("access")?:"").put("refresh",intent.getStringExtra("refresh")?:""))}}}}
 private val permission=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ r ->
  val webRequest=pendingWebMic;pendingWebMic=null
  if(webRequest!=null){if(r[Manifest.permission.RECORD_AUDIO]==true)webRequest.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))else webRequest.deny()}
  else if(r[Manifest.permission.RECORD_AUDIO]==true)startNative() else {Toast.makeText(this,"Microphone permission denied. Text chat remains available.",Toast.LENGTH_LONG).show();dispatchWeb("nativeVoiceStateChanged",JSONObject().put("state","error").put("message","Microphone permission denied."))}
 }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); window.statusBarColor=android.graphics.Color.rgb(248,246,252); web=WebView(this); setContentView(web)
  web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.mediaPlaybackRequiresUserGesture=false; web.settings.allowFileAccess=false; web.settings.allowContentAccess=true
  web.webChromeClient=object:WebChromeClient(){ override fun onPermissionRequest(req:PermissionRequest){runOnUiThread{
   val trusted=req.origin.scheme=="https"&&req.origin.host=="appassets.androidplatform.net"
   val audioOnly=req.resources.all{it==PermissionRequest.RESOURCE_AUDIO_CAPTURE}
   if(!trusted||!audioOnly){req.deny();return@runOnUiThread}
   if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)req.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
   else{pendingWebMic=req;permission.launch(arrayOf(Manifest.permission.RECORD_AUDIO))}
  }} }
  val assetLoader=WebViewAssetLoader.Builder().addPathHandler("/assets/",WebViewAssetLoader.AssetsPathHandler(this)).build()
  pendingOAuth=intent?.data
  web.webViewClient=object:WebViewClient(){override fun onPageFinished(v:WebView?,url:String?){super.onPageFinished(v,url);pendingOAuth?.let{pendingOAuth=null;deliverOAuth(it)}};override fun shouldInterceptRequest(v:WebView?,r:WebResourceRequest)=assetLoader.shouldInterceptRequest(r.url);override fun shouldOverrideUrlLoading(v:WebView?,r:WebResourceRequest):Boolean { val u=r.url; if(u.scheme=="ai.eliteauraxp.app"&&u.host=="auth")return true; if(u.scheme=="https" && u.host!="appassets.androidplatform.net"){startActivity(Intent(Intent.ACTION_VIEW,u));return true};return false }}
  WebView.setWebContentsDebuggingEnabled(false); web.addJavascriptInterface(Bridge(),"AvniNative")
  val filter=IntentFilter().apply{addAction("ai.eliteauraxp.VOICE_STATE");addAction("ai.eliteauraxp.VOICE_TRANSCRIPT");addAction("ai.eliteauraxp.VOICE_SESSION_REFRESHED")}
  registerVoiceReceiver(filter);serviceReceiverRegistered=true
  web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
 }
 @Suppress("DEPRECATION") private fun registerVoiceReceiver(filter:IntentFilter){if(Build.VERSION.SDK_INT>=33)registerReceiver(serviceReceiver,filter,Context.RECEIVER_NOT_EXPORTED)else registerReceiver(serviceReceiver,filter)}
 private fun dispatchWeb(name:String,detail:JSONObject){if(::web.isInitialized)runOnUiThread{web.evaluateJavascript("window.dispatchEvent(new CustomEvent("+JSONObject.quote(name)+",{detail:"+detail.toString()+"}))",null)}}
 inner class Bridge { @JavascriptInterface fun updateSupabaseSession(token:String,refreshToken:String){VoiceSessionService.updateSessionTokens(token,refreshToken);if(token.isBlank())command("STOP")}; @JavascriptInterface fun startVoiceSession(){runOnUiThread{if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)permission.launch(arrayOf(Manifest.permission.RECORD_AUDIO,Manifest.permission.POST_NOTIFICATIONS)) else startNative()}}; @JavascriptInterface fun pauseVoiceSession(){command("PAUSE")}; @JavascriptInterface fun resumeVoiceSession(){command("RESUME")}; @JavascriptInterface fun stopVoiceSession(){command("STOP")}; @JavascriptInterface fun getVoiceSessionState():String=VoiceSessionService.currentState; @JavascriptInterface fun sendTextToNativeVoice(text:String){VoiceSessionService.speak(this@MainActivity,text)}
 }
 private fun startNative(){ val i=Intent(this,VoiceSessionService::class.java).setAction("START"); if(Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i)}
 private fun command(a:String){startService(Intent(this,VoiceSessionService::class.java).setAction(a))}
 fun js(name:String,value:String){runOnUiThread{if(::web.isInitialized)web.evaluateJavascript("window.dispatchEvent(new CustomEvent('$name',{detail:$value}))",null)}}
 private fun deliverOAuth(uri:Uri){if(uri.scheme=="ai.eliteauraxp.app"&&uri.host=="auth"&&uri.path=="/callback")web.evaluateJavascript("window.dispatchEvent(new CustomEvent('avniOAuthCallback',{detail:{url:"+JSONObject.quote(uri.toString())+"}}))",null)}
 override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);intent.data?.let{uri->if(::web.isInitialized)deliverOAuth(uri)else pendingOAuth=uri}}
 override fun onDestroy(){if(serviceReceiverRegistered){unregisterReceiver(serviceReceiver);serviceReceiverRegistered=false};pendingWebMic?.deny();pendingWebMic=null;super.onDestroy()}
 override fun onBackPressed(){if(web.canGoBack())web.goBack()else super.onBackPressed()}
}
