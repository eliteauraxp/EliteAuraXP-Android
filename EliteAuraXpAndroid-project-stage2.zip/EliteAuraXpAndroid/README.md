# EliteAuraXp Android wrapper

## Source audit
`app/src/main/assets/index.html` is the supplied 430 KB / 2,891-line source app. Its study UI/features, localStorage, Supabase auth/profile, AI provider settings, Avni/Dev prompts, Dev chat, TTS, image generation and themes are retained. Changes are targeted: the STT request routes through authenticated Supabase `/functions/v1/stt`, Android native voice UI starts the foreground STT session, session tokens are synced to native memory, and permission/transcript callbacks are handled. Other existing provider pathways remain untouched.

## Build (phone-only)
1. Upload this whole folder as a GitHub repository (or copy the project files).
2. GitHub → Actions → “Build APK” → Run workflow.
3. Open run → Artifacts → `EliteAuraXp-debug-apk` → download/unzip `app-debug.apk`.
4. Install on Android; allow install-from-this-source. Debug APK is unsigned for Play release.

Local: Android Studio, JDK 17, Android SDK 35; `gradle assembleDebug`. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Stage 2 STT implementation
The client STT path now posts recorded `Blob` audio from the existing foreground voice-typing and voice-call flows to `https://sfbyltxmezgebfrdvzgi.supabase.co/functions/v1/stt`, using the active Supabase access token (`Authorization: Bearer …`) and the existing publishable key (`apikey`). It sends multipart fields `file`, `model=whisper-large-v3-turbo`, `response_format=json`, `temperature=0`, plus optional `language` and `prompt`. It accepts JSON `text` or `transcript`. No Groq secret is placed in the APK or used by the STT frontend path.

The native foreground service now captures mono 16 kHz PCM after explicit Start, applies a simple energy/silence VAD, wraps each speech segment as WAV, and posts it to the same function using the current authenticated session JWT. It checks HTTP errors, reports transcript/state/error events back to a live WebView, cancels its active HTTP request on Stop, and refreshes a Supabase session once after an HTTP 401 using the in-memory refresh token. Native capture requires the user to be signed in. Transcripts are placed into the existing chat input for review; this stage does **not** auto-submit them to Avni.

Foreground WebView recording is now allowed only for the bundled `appassets.androidplatform.net` origin and only for audio capture after Android runtime microphone permission. Other WebView origins/resources are denied. On Android, automatic microphone voice typing prefers the configured Whisper path via the Edge Function; on the normal website the previous browser/provider mode remains available.

**Foreground vs. background:** browser `MediaRecorder` and its Blob/STT path operate only while the WebView is active. The native AudioRecord + foreground-service + Edge Function path is the background-capable STT implementation and does not depend on WebView recording. Android/OEM policy may still terminate or restrict a session. This stage implements STT only; background Avni response generation, native TTS, and a full continuous speech/AI/audio loop are not implemented.

## Existing Edge Function contract to verify
The ZIP does not contain the deployed Edge Function source and I cannot inspect the Supabase deployment from this workspace. The client uses the natural multipart contract matching the original HTML's Groq transcription request and expects a JSON `text` or `transcript` field. Verify the existing `/functions/v1/stt` function accepts that multipart schema, validates the Supabase user JWT, uses server-side `Deno.env.get('GROQ_API_KEY')`, and forces Groq `whisper-large-v3-turbo`. It should return clear 4xx/5xx JSON errors and configure CORS for the web deployment origins. If its deployed request/response contract differs, adapt the client or function rather than adding a new route. The function secret is configured in Supabase (not in this repository); never paste it into the app or chat.

Android permits continued microphone FGS only after explicit user action/permission and subject to OS/OEM policy. Android 14+ restrictions, notification permission, battery management, calls/audio focus, process death, lock-screen behavior and OEM termination may limit continuity. No always-listening or restriction bypass. `START_NOT_STICKY`; service stops on capture error.

## Configuration / security
- Supabase URL + anon/public key already appear in source; verify RLS on every table and restrict OAuth redirect allow-lists. Existing provider keys/config are fetched from `ai_config` and some are kept client-side/localStorage. **Rotate any secrets ever embedded in this HTML.** Move Groq/HF/Pixazo/Gemini/Sarvam secrets behind authenticated server-side proxy; keep admin configuration schema but store secret references server-side. Do not put service-role keys in APK.
- Supabase public config is already in the supplied HTML and remains unchanged: project URL `https://sfbyltxmezgebfrdvzgi.supabase.co`; publishable/anon key `sb_publishable_euG-QCULvyGyB42D0C4f1g_VWV5-l-n`. This key is public client configuration, not a service-role secret.
- Android loads the bundled asset at `https://appassets.androidplatform.net/assets/index.html` through `WebViewAssetLoader` (not `file://`), preserving localStorage under a stable secure origin. Google OAuth now requests redirect URI `ai.eliteauraxp.app://auth/callback`; the WebView OAuth PKCE verifier remains in the existing Supabase JS client's localStorage, and the native callback hands the returned authorization code back to that client for `exchangeCodeForSession`. Web sign-in still uses the original website redirect.
- Supabase Dashboard → Authentication → URL Configuration → add `ai.eliteauraxp.app://auth/callback` to Redirect URLs. Authentication → Providers → Google: enable Google and configure its OAuth client. In Google Cloud, set the Supabase provider callback shown by Supabase (typically `https://sfbyltxmezgebfrdvzgi.supabase.co/auth/v1/callback`) as an Authorized redirect URI; configure the corresponding client ID/secret in Supabase, never in this APK. Confirm Google provider settings in Supabase and test callback on device. Keep RLS enabled.
- Android manifest package/scheme is `ai.eliteauraxp.app`; changing applicationId requires updating the scheme and Supabase allow-list.
- The STT client targets the supplied project's existing `/functions/v1/stt` route. No function source was in the ZIP, so deployed schema, `GROQ_API_KEY`, JWT verification, and actual inference must be confirmed in Supabase; this project does not deploy or claim to verify the function.

## Permissions
INTERNET, RECORD_AUDIO (runtime), FOREGROUND_SERVICE, FOREGROUND_SERVICE_MICROPHONE, POST_NOTIFICATIONS (Android 13+ runtime), WAKE_LOCK. Denial leaves HTML text/chat available. No location/storage/contacts.

## Phone testing — Stage 2 STT
1. In Supabase, confirm the existing `stt` Edge Function is deployed at this project's `/functions/v1/stt`; configure the function secret named `GROQ_API_KEY` in Supabase Function Secrets (never in HTML, GitHub, or the APK). Ensure the function authenticates the caller's Supabase JWT, uses `whisper-large-v3-turbo`, accepts multipart `file`/`model`/optional `language`/`prompt`, and returns `{\"text\":\"...\"}` or `{\"transcript\":\"...\"}`. Do not create a duplicate route if your current function differs; align the client schema to its actual contract.
2. Build and install the APK using the GitHub Actions steps above. Open EliteAuraXp and sign in with Google (or email/password). Stay signed in; the WebView forwards only current access/refresh tokens to the in-process bridge/service, not to logs or persistent app storage.
3. Open Avni voice chat and start the session. Grant Android Microphone permission. Speak a clear sentence and pause. In foreground, test the mic button (MediaRecorder → Blob → Edge Function). For native/background STT, use the voice-session start in Avni voice UI; the persistent notification should show `listening` then `processing stt`, then return to listening. Confirm recognized text appears in the chat input/voice transcript area for review (it is not auto-sent to Avni at this stage).
4. Minimize the app while the native session is listening, speak after switching apps, then return and inspect transcript. Try Pause, Resume, Stop from notification and End from UI. Check that Stop removes the notification and releases the microphone. Test denied microphone, signed-out session, offline/network failure, and function 401/429/500 responses; expected behavior is a visible error, no crash, and safe stop/return to listening as applicable.
5. If the function returns 404, check its deployed route/name; if 401, check sign-in/JWT validation; if 400, compare multipart schema; if 500, inspect Edge Function logs without printing the API secret. Never put `GROQ_API_KEY` in client logs.

A successful build, deployment, real device test, or actual inference has **not** been verified from this workspace. This ZIP contains the client-side integration only; the Supabase function must already exist and be configured. OAuth code added in the earlier stage remains as-is.

## Bridge
`window.AvniNative.updateSupabaseSession(accessToken, refreshToken)`, `startVoiceSession()`, `pauseVoiceSession()`, `resumeVoiceSession()`, `stopVoiceSession()`, `getVoiceSessionState()`, and the existing `sendTextToNativeVoice(text)`. Service broadcasts `nativeVoiceStateChanged`, `nativeVoiceTranscript`, and `nativeVoiceError` to a live WebView; transcripts populate the existing chat input for review.

## Audit findings and known caveats
- The supplied HTML still contains its other legacy provider-key/configuration pathways for chat/TTS/image features. Stage 2 removes direct Groq-key use from the STT request path only; it does not migrate all unrelated AI provider traffic.
- The Edge Function was not part of the uploaded ZIP and the Supabase deployment is not accessible from this workspace. The client assumes multipart input and a JSON transcript field; actual deployed contract and `GROQ_API_KEY` configuration require verification.
- Native background STT captures and sends transcript segments, but does not call Avni AI, does not auto-submit transcripts, and does not provide background TTS. Full continuous voice conversation is not claimed.
- WebView JavaScript microphone requests are granted only for the asset-loader app origin and only for the microphone resource, after Android runtime permission. The native AudioRecord service is independent of WebView capture and starts only from explicit user action.
- Android service lifecycle, OAuth, foreground mic policy, OEM battery behavior, and image generation were not end-to-end tested here. External navigation opens outside WebView; the JS bridge is intended only for bundled app content.
